import java.util.Scanner;

class Principal {

	private static int resolve (int n, int m, int o) {
		
		int resultado = 2;		
				
		return resultado; 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int resultado;
        
        String parametros[];    
        
        Scanner input = new Scanner (System.in);
        String line;
        
        int T, n, o, m, j = 0;
        
        line = input.nextLine();        
        T = Integer.parseInt(line);
        
        while(j < T)
        {    
        	line = input.nextLine();

            parametros = line.split(" ");
            
            n = Integer.parseInt(parametros[0]);	//numero de alunos
            m = Integer.parseInt(parametros[1]);	//primeiro aluno que inicia com o papel
            o = Integer.parseInt(parametros[2]);	//quantidade ate o proximo aluno
            
            resultado = resolve (n, m, o);
            
            System.out.println(resultado);
            
            j++;
        }     
	}

}
