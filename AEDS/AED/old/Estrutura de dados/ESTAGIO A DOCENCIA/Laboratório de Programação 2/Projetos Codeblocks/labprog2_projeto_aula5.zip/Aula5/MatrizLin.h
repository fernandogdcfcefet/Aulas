#ifndef MatrizLin_H_INCLUDED
#define MatrizLin_H_INCLUDED

class MatrizLin
{
    private:
        float *vet;
        int nl, nc;
        int detInd(int linha, int coluna);
    public:
        MatrizLin(int mm, int nn);
        void atribui(int linha, int coluna, float valor);
        float consulta(int linha, int coluna);
        ~MatrizLin();
};

#endif // MatrizLin0_H_INCLUDED
