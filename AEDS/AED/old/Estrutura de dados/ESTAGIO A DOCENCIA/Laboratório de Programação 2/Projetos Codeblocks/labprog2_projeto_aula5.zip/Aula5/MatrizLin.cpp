#include <iostream>
#include <cstdlib>

#include "MatrizLin.h"

using namespace std;

MatrizLin::MatrizLin(int mm, int nn)
{
    cout << "Criando (MatrizLin)" << endl;
    nl = mm;
    nc = nn;
    vet = new float[nl*nc];
}

MatrizLin::~MatrizLin()
{
    cout << "Destruindo (MatrizLin)" << endl;
    delete [] vet;
}

int MatrizLin::detInd(int linha, int coluna)
{
    if(linha >= 0 && linha < nl && coluna >= 0 && coluna < nc)
        return nc*linha + coluna;
    else
        return -1;
}

float MatrizLin::consulta(int linha, int coluna)
{
    int k = detInd(linha, coluna);
    if(k != -1)
        return vet[k];
    else
    {
        cout << "Indice invalido!" << endl;
        exit(1);
    }
}

void MatrizLin::atribui(int linha, int coluna, float valor)
{
    int k = detInd(linha, coluna);
    if(k != -1)
        vet[k] = valor;
    else
    {
        cout << "Indice invalido!" << endl;
        exit(1);
    }
}

