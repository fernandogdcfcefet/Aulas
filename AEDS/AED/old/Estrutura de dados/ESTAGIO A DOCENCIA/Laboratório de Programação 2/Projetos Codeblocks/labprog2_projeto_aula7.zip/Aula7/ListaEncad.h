#ifndef LISTASENCAD_H_INCLUDED
#define LISTASENCAD_H_INCLUDED

#include "No.h"

class ListaEncad
{
  public:
    ListaEncad();
    ~ListaEncad();
    bool busca(float val);
    void inserePri(float val); // insere um novo n� contendo val no in�cio da lista
    void eliminaPri();         // elimina o primeiro n� da lista

    // Exercicios 1 e 2

  private:
    No* primeiro;  // ponteiro para o primeiro No da lista
    No* ultimo;    // ponteiro para o ultimo No da lista
    int n;         // contador
};
#endif
