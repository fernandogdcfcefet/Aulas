#include <iostream>
#include <stdlib.h> //rand()
#include <time.h>   //time()

#include "ListaEncad.h"

using namespace std;

int numAleatorio(int a, int b)
{
    // retorna um numero inteiro aleat�rio entre a e b
    return a + rand()%(b - a + 1) ;
}

int main()
{
    // cria lista vazia
    ListaEncad l;
    int NumNos = 12;

    srand(time(NULL));

    //
    // ATENCAO: os valores inseridos na lista sao gerados
    // aleatoriamente e mudam em cada execucao do programa!!!
    //
    cout << "Inserindo valores: ";
    for(int i = 1; i <= NumNos; i++)
    {
        // cria um valor aleat�rio entre 0 e 50
        float val =  numAleatorio(0, 50);
        cout << val << ", ";
        l.inserePri(val);
    }
    cout << endl;

    bool existe = l.busca(20);
    cout << "O valor 20 esta na lista? ";
    if(existe)
        cout << "Sim" << endl;
    else
        cout << "Nao" << endl;

    return 0;
};

