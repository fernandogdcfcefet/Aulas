#include <iostream>
#include "ArvBin.h"
using namespace std;

int main()
{
    //constr�i 5 �rvores bin�rias vazias
    ArvBin *arv = new ArvBin();
    ArvBin *a1 = new ArvBin();
    ArvBin *a2 = new ArvBin();
    ArvBin *a3 = new ArvBin();
    ArvBin *vazia = new ArvBin();

    //as 2 arvores possuem ra�zes 6 e 9 e sae e sad vazias
    a1->cria(6, vazia, vazia);
    a2->cria(9 ,vazia, vazia);

    //raiz de Arv tem valor 8 e sae a1 e sad a2
    arv->cria(8, a1, a2);

    a1->cria(18, vazia, vazia);
    a2->cria(14, vazia, vazia);
    a3->cria(-5, a1, a2);

    //raiz de Arv tem valor 10 e sae Arv e sad a3
    arv->cria(10, arv, a3);

    a1->cria(25, vazia, vazia);
    a2->cria(33, vazia, vazia);
    a3->cria(30, a1, a2);

    //raiz de Arv tem valor 20 e sae Arv e sad a3
    arv->cria(20, arv, a3);

    //
    // TESTES: faca seus testes aqui
    //

    //imprime a �rvore constru�da nos comandos acima
    arv->emOrdem();

    //
    // FIM DOS TESTES
    //

    delete arv;

    return 0;
}
