#ifndef ARVBIN_H_INCLUDED
#define ARVBIN_H_INCLUDED
#include "No.h"

class ArvBin
{
  public:
    ArvBin();
    ~ArvBin();
    int consultaRaiz();
    void cria(int x, ArvBin *sae, ArvBin *sad);
    bool vazia(); // verifica se a �rvore est� vazia
    bool busca(int x);
    void emOrdem();

  private:
    No* raiz; // ponteiro para o No raiz da �rvore
    bool auxBusca(No *p, int C);
    No* libera(No *p);
    void auxEmOrdem(No *p);

};

#endif // ARVBIN_H_INCLUDED
