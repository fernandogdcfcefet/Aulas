#include <iostream>
#include <cstdlib>
#include "ArvBin.h"

using namespace std;

ArvBin::ArvBin()
{
    raiz = NULL;
}

int ArvBin::consultaRaiz()
{
    if (raiz != NULL)
        return raiz->consultaInfo();
    else
    {
        cout << "�rvore vazia!" << endl;
        exit(1);
    }
}

void ArvBin::cria(int x, ArvBin *sae, ArvBin *sad)
{
    No *p = new No();
    p->atribInfo(x);
    p->atribEsq(sae->raiz);
    p->atribDir(sad->raiz);
    raiz = p;
}

bool ArvBin::vazia()
{
    if (raiz == NULL)
        return true;
    else
        return false;
}

bool ArvBin::busca(int x)
{
    return auxBusca(raiz, x);
}

bool ArvBin::auxBusca(No *p, int C)
{
    if (p == NULL)
        return false;
    else if (p->consultaInfo() == C)
        return true;
    else if (auxBusca(p->consultaEsq(), C))
        return true;
    else
        return auxBusca(p->consultaDir(), C);
}

ArvBin::~ArvBin()
{
    raiz = libera(raiz);
}

No* ArvBin::libera(No *p)
{
    if (p != NULL)
    {
        p->atribEsq(libera(p->consultaEsq()));
        p->atribDir(libera(p->consultaDir()));
        delete p;
        p = NULL;
    }
    return NULL;

}

void ArvBin::emOrdem()
{
    cout << "Arvore Binaria: ";
    auxEmOrdem(raiz);
}

void ArvBin::auxEmOrdem(No *p)
{
    if (p != NULL)
    {
        auxEmOrdem(p->consultaEsq());
        cout << p->consultaInfo() << " ";
        auxEmOrdem(p->consultaDir());
    }
}
