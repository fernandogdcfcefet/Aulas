#ifndef NO_H_INCLUDED
#define NO_H_INCLUDED

class No
{
  private:
    No* esq; // ponteiro para o filho a esquerda
    int info; // informa��o do No (int)
    No* dir; // ponteiro para o filho a direita
  public:
    No()                    {};
    void atribEsq(No* p)    { esq = p; };
    void atribInfo(int val) { info = val; };
    void atribDir(No* p)    { dir = p; };
    No* consultaEsq()       { return esq; };
    int consultaInfo()      { return info; };
    No* consultaDir()       { return dir; };
    ~No()                   {};
};

#endif // NO_H_INCLUDED
