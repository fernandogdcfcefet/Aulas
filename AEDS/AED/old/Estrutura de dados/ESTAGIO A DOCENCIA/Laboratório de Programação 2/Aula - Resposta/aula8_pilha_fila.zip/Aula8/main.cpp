#include <iostream>

#include "PilhaEncad.h"
#include "FilaEncad.h"

using namespace std;

//Exercicio 3

float* inverte(float *vet, int n)
{
    float *novoVet = new float[n];
    PilhaEncad p;

    for(int i = 0; i < n; i++) p.empilha(vet[i]);

    for(int i = 0; i < n; i++)
    {
        novoVet[i] = p.consultaTopo();
        p.desempilha();
    }

    return novoVet;
}

//Exercicio 4
void inverteFila(FilaEncad* f, PilhaEncad* p)
{
    float aux;

    while(!(f->vazia()))
    {
        aux = f->consultaInicio();
        p->empilha(aux);
        f->sai();
    }

    while(!(p->vazia()))
    {
        aux = p->consultaTopo();
        f->entra(aux);
        p->desempilha();
    }
}

// Exercicio 5
FilaEncad* concatena(FilaEncad * f1, FilaEncad * f2)
{
    FilaEncad * novaFila = new FilaEncad();
    float aux;

    while(!(f1->vazia()))
    {
        aux = f1->consultaInicio();
	    if(!novaFila->busca(aux))
	        novaFila->entra(aux);
        f1->sai();
    }

    while(!(f2->vazia()))
    {
        aux = f2->consultaInicio();
	    if(!novaFila->busca(aux))
	        novaFila->entra(aux);
        f2->sai();
    }

    return novaFila;
}

// Exercicio 6
void removeDaPilha(PilhaEncad * p, float X)
{
    PilhaEncad Paux;
    float v;

    while(!p->vazia() && p->consultaTopo() != X)
    {
        v = p->consultaTopo();
	    Paux.empilha(v);
        p->desempilha();
    }

    if(!p->vazia() && p->consultaTopo() == X)
        p->desempilha();

    while(!Paux.vazia())
    {
        v = Paux.consultaTopo();
	    p->empilha(v);
        Paux.desempilha();
    }
}

int main()
{
    //
    // TESTE COM PILHA
    //
    PilhaEncad p;

    for(int i=0; i<5; i++) p.empilha(i);
    cout << "Pilha apos inserir 5 valores" << endl;
    p.imprime();

    cout << "Tamanho da Pilha: " << p.tamanho() << endl;


    for(int i=20; i<25; i++) p.empilha(i);
    cout << "Pilha apos inserir mais 5 valores" << endl;
    p.imprime();

    cout << "Tamanho da Pilha: " << p.tamanho() << endl;

    float vet[10];
    for(int i = 0; i < 10; i++) vet[i] = i;


    /*---------------------
         EXERCICIO 3
     ---------------------*/


    cout << "\n\nExercicio 3 \n" << endl;

    cout << "Vetor de Numeros: ";
    for(int i = 0; i < 10; i++)
        cout << vet[i] << "  ";
    cout << endl;

    float *novoVet;
    novoVet = inverte(vet,10);

    cout << "Vetor de Numeros: ";
    for(int i = 0; i < 10; i++)
        cout << novoVet[i] << "  ";
    cout << endl;

    delete [] novoVet;


    /*---------------------
         EXERCICIO 4
     ---------------------*/

    cout << "\n\nExercicio 4 \n" << endl;

    FilaEncad f;
    PilhaEncad p1;
    for(int i=0; i<5; i++) f.entra(i);
    f.imprime();

    inverteFila(&f, &p1);
    f.imprime();

    /*---------------------
         EXERCICIO 5
     ---------------------*/

    cout << "\n\nExercicio 5 \n" << endl;

    FilaEncad f1, f2;
    for(int i=0; i<5; i++) f1.entra(i);

    for(int i=6; i<11; i++) f2.entra(i);

    cout << "f1: ";
    f1.imprime();

    cout << "f2: ";
    f2.imprime();

    FilaEncad *f3 = concatena(&f1, &f2);

    cout << "Fila resultante da concatenacao de f1 e f2: " << endl;
    f3->imprime();
    delete f3;

    /*---------------------
         EXERCICIO 6
     ---------------------*/

    cout << "\n\nExercicio 6 \n" << endl;

    PilhaEncad p2;
    for(int i=0; i<11; i++) p2.empilha(i);

    cout << "pilha: ";
    p2.imprime();

    removeDaPilha(&p2, 10);

    cout << "Remove(8): ";
    p2.imprime();

    return 0;
}
