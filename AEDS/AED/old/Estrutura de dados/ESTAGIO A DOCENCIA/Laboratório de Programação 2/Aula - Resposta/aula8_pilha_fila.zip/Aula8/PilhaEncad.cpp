#include "PilhaEncad.h"

// construtor
PilhaEncad::PilhaEncad()
{
    cout << "Criando PilhaEncad" << endl;
    topo = NULL;
    tam = 0;
}

// destrutor
PilhaEncad::~PilhaEncad()
{
    cout << "Destruindo PilhaEncad" << endl;
    No* p = topo;
    tam = 0;
    while(topo != NULL)
    {
        topo = p->getProx();
        delete p;
        p = topo;
    }
}

void PilhaEncad::empilha(float val)
{
    No* p = new No();
    p->setInfo(val);
    p->setProx(topo);
    topo = p;
    tam++;
}

void PilhaEncad::desempilha()
{
    No* p;
    if(topo != NULL)
    {
        p = topo;
        topo = p->getProx();
        tam--;
        delete p;
    }
    else
    {
        cout << "Erro" << endl;
        exit(1);
    }
}

float PilhaEncad::consultaTopo()
{
    if(topo != NULL)
        return topo->getInfo();
    else
    {
        cout << "Pilha vazia!" << endl;
        exit(1);
    }
}

bool PilhaEncad::vazia()
{
    if(topo == NULL)
        return(true);
    else
        return(false);
}

void PilhaEncad::imprime()
{
    if(vazia())
        cout << "Pilha vazia!" << endl;
    else
    {
        for(No *p = topo; p != NULL; p = p->getProx())
            cout << p->getInfo() << "  ";
        cout << endl;
    }
}

int PilhaEncad::tamanho()
{
    return tam;
}

