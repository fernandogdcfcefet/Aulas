#include <iostream>
#include <stdlib.h> //rand()
#include <time.h>   //time()

#include "ListaEncad.h"

using namespace std;

int numAleatorio(int a, int b)
{
    // retorna um numero inteiro aleat�rio entre a e b
    return a + rand() % (b - a + 1) ;
}

int main()
{
    // cria lista vazia
    ListaEncad *l = new ListaEncad();
    int NumNos = 12;

    srand(time(NULL));

    //
    // ATENCAO: os valores inseridos na lista sao gerados
    // aleatoriamente e mudam em cada execucao do programa!!!
    //

    cout << "Inserindo valores: ";
    for(int i = 1; i <= NumNos; i++)
    {
        // cria um valor aleat�rio entre 0 e 50
        float val =  numAleatorio(0, 50);
        l->inserePri(val);
    }
    cout << endl;

    l->imprime();
    cout << "Numero de nos: " << l->numNos() << endl;
    cout << "Media dos valores: " << l->calculaMedia() << endl;

    //cria lista l2 e adiciona 3 nos
    ListaEncad *l2 = new ListaEncad();
    l2->inserePri(10);
    l2->inserePri(20);
    l2->inserePri(30);

    //concatena l e l2 e armazena o resultado em l3
    ListaEncad *l3 = l->concatena(l2);
    cout << "Lista concatenada:" << endl;
    l3->imprime();

    //parte a lista l3 no elemento de valor "30"
    ListaEncad *l4 = l3->partir(30);
    cout << "Lista 1: " << endl;
    l3->imprime();

    cout << "Lista 2: " << endl;
    l4->imprime();

    delete l;
    delete l2;
    delete l3;
    delete l4;

    return 0;
};
