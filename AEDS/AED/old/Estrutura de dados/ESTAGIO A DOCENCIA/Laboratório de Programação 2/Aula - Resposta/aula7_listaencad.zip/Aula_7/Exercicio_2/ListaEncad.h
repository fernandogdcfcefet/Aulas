#ifndef LISTASENCAD_H_INCLUDED
#define LISTASENCAD_H_INCLUDED

#include "No.h"

class ListaEncad
{
  public:
    ListaEncad();
    ~ListaEncad();
    bool busca(float val);
    void eliminaPri();         // elimina o primeiro n� da lista

    // Exercicios 1 e 2

    void imprime();
    int numNos();
    int buscaMaior(float val);
    float calculaMedia();
    ListaEncad* concatena(ListaEncad *l2);
    ListaEncad* partir(float x);

    void insereOrdenado(float val);

  private:
    No* primeiro;  // ponteiro para o primeiro No da lista
    No* ultimo;    // ponteiro para o ultimo No da lista
    int n;         // contador
};
#endif

