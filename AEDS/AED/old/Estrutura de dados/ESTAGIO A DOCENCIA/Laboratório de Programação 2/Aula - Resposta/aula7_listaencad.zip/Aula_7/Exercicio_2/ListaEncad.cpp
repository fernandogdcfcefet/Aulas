#include <iostream>
#include <stdlib.h>

#include "ListaEncad.h"

using namespace std;

ListaEncad::ListaEncad()
{
    cout << "Criando uma ListaEncad" << endl;
    primeiro = NULL;
    ultimo = NULL;
    n = 0;
}

ListaEncad::~ListaEncad()
{
    cout << "Destruindo ListaEncad" << endl;
    No* p = primeiro;
    while(p != NULL)
    {
        No* t = p->getProx();
        delete p;
        p = t;
    }
}

bool ListaEncad::busca(float val)
{
    No* p;
    for(p = primeiro; p != NULL; p = p->getProx())
    {
        if(p->getInfo() == val)
            return true;
    }
    return false;
}

void ListaEncad::eliminaPri()
{
    No* p;
    if(primeiro != NULL)
    {
        p = primeiro;
        primeiro = p->getProx();
        delete p;

        n--;
        if(n == 0) ultimo = NULL;

    }
    else
    {
        cout << "ERRO: lista vazia" << endl;
    }
}

// Exercicio 1

void ListaEncad::imprime()
{
    No* p;
    for(p = primeiro; p != NULL; p = p->getProx())
    {
        cout << p->getInfo();

        if(p->getProx() != NULL)
            cout << ", ";
    }
    cout << endl;
}

int ListaEncad::numNos()
{
    No* p;
    int numNos = 0;

    for(p = primeiro; p != NULL; p = p->getProx())
        numNos++;

    return numNos;
}

int ListaEncad::buscaMaior(float val)
{
    No* p;
    int posicao = 0;
    for(p = primeiro; p != NULL; p = p->getProx(), posicao++)
        if(p->getInfo() > val)
            return posicao;

    return -1;
}

float ListaEncad::calculaMedia()
{
    if(n == 0)
    {
        cout << "ERRO: lista vazia" << endl;
        exit(1);
    }

    No* p;
    float media = 0;

    for(p = primeiro; p != NULL; p = p->getProx())
        media+= p->getInfo();

    media = media/n;

    return media;
}

ListaEncad* ListaEncad::concatena(ListaEncad *l2)
{
    No *p;
    ListaEncad *l3 = new ListaEncad();

    //Copia nos da primeira lista
    for(p = primeiro; p != NULL; p = p->getProx())
        l3->insereOrdenado(p->getInfo());

    //Copia nos da segunda lista
    for(p = l2->primeiro; p != NULL; p = p->getProx())
        l3->insereOrdenado(p->getInfo());

    //Retorna a lista resultante
    return l3;
}

ListaEncad* ListaEncad::partir(float x)
{
    cout << "Partindo a lista em (x = " << x << "):" << endl;

    No *p;
    ListaEncad *l2  = new ListaEncad();

    //Procura pelo no com o valor "x"
    for(p = primeiro; p != NULL; p = p->getProx())
    {
        if(p->getInfo() == x)
            break;
    }

    if(p == NULL)
    {
        cout << "O valor " << x << " nao foi encontrado na lista." << endl;

        //Retorna uma lista vazia
        return l2;
    }
    else
    {
        //A segunda lista se inicia no sucessor daquele que possui o valor "x" (no p),
        //e vai ate o ultimo elemento da lista inicial.
        l2->primeiro = p->getProx();
        l2->ultimo = ultimo;
        l2->n = l2->numNos();

        //"Corta" a primeira lista no elemento de valor "x"
        ultimo = p;

        if(ultimo != NULL)
            ultimo->setProx(NULL);

        //Atualiza o numero de nos
        n = numNos();

        return l2;
    }
}

// Exercicio 2

void ListaEncad::insereOrdenado(float val)
{
    No* p = NULL, *predecessor = NULL;

    //Procura pelo primeiro no maior que "val"
    for(p = primeiro; p != NULL; p = p->getProx())
    {
        if(p->getInfo() >= val)
            break;
        else
            predecessor = p;
    }

    No* no = new No();
    no->setInfo(val);

    if(predecessor == NULL)
    {
        if(n == 0){
            //Lista vazia: o novo valor eh inserido no começo
            no->setProx(NULL);
            primeiro = ultimo = no;
        }
        else{
            //O valor a ser inserido eh menor que todos da lista
            no->setProx(primeiro);
            primeiro = no;
        }
    }
    else
    {
        //Insere o novo no entre os nos "predecessor" e "p"
        predecessor->setProx(no);
        no->setProx(p);

        if(ultimo == predecessor)
            ultimo = no;
    }

    n++;
}
