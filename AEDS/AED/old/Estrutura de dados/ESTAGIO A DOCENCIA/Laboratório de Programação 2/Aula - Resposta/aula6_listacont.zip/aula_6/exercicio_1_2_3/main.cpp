#include <iostream>
#include <stdlib.h> //rand()
#include <time.h>   //time()
#include "Ponto2D.h"
#include "ListaCont.h"

using namespace std;

int numAleatorio(int a, int b)
{
    // retorna um numero inteiro aleatório entre a e b
    return a + rand()%(b - a + 1) ;
}

int main()
{
    srand(time(NULL));

    ListaCont l(10);

    l.insereUlt(2.476);
    l.insereUlt(3.1465);
    l.insereUlt(2.718);
    l.insereUlt(-1.10);
    l.insereUlt(1.5);
    l.insereUlt(6);
    l.insereUlt(1.0);

    l.imprime();

    float maior = 10;

    cout << "Indice do elemento maior que o parametro " << maior << ": " << l.buscaMaior(maior) << endl;
    cout << "Numero de nos: " << l.numNos() << endl;

    /*---------------------
         EXERCICIO 2
     ---------------------*/

    cout << "\nExercicio 2"<< endl;

    int tam = 3;

    float vet[tam];

    for(int i = 0; i < tam; i++)
    {
        // cria um valor aleatório entre 0 e 50
        float val = numAleatorio(0, 50);
        vet[i] = val;
    }

    l.insereValores(tam, vet);

    l.imprime();
    cout << "Indice do elemento maior que o parametro: " << maior << ": " << l.buscaMaior(maior) << endl;
    cout << "Numero de nos: " << l.numNos() << endl;


    /*---------------------
         EXERCICIO 3
     ---------------------*/

    cout << "\nExercicio 3"<< endl;

    ListaCont l1(50);
    ListaCont l2(50);
    ListaCont l3(50);

    for(int i = 0; i < 50; i++)
    {
        // cria um valor aleatório entre 0 e 50
        float val = numAleatorio(0, 50);
        l1.insereUlt(val);
    }

    cout << "Lista 1: "<< endl;
    l1.imprime();

    //copia primeira metade da lista l1 para a lista l2

    for(int i = 0; i < 25; i++)
    {
        l2.insereUlt(l1.consulta(0));
        l1.eliminaK(0);
    }

    // copia segunda metade da lista l1 para a lista l3

    for(int i = 0; i < 25; i++)
    {
        l3.insereUlt(l1.consulta(0));
        l1.eliminaK(0);

    }
    cout << "Lista 2: "<< endl;
    l2.imprime();
    cout << "Lista 3: "<< endl;
    l3.imprime();

    return 0;
}
