#ifndef TLISTCONT_H_INCLUDED
#define TLISTCONT_H_INCLUDED


#include "Ponto2D.h"

class ListaCont
{
    private:
        int max;
        int ultimo;
        Ponto2D** x;

    public:
        ListaCont(int tam);
        ~ListaCont();

        Ponto2D* consulta(int k);
        void atribui(int k, Ponto2D* val);
        void insereK(int k, Ponto2D* val);
        void insereUlt(Ponto2D* val);
        void eliminaK(int k);
        void eliminaUlt();
        void imprime();
        int numNos();
        void limpar();
        void insereValores(int tam, Ponto2D* vet[]);
        void calculaDistPontos();
};

#endif // TLISTCONT_H_INCLUDED
