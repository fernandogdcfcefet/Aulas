#include <iostream>
#include <cstdlib>

#include "ListaCont.h"

using namespace std;

ListaCont::ListaCont(int tam)
{
    cout << "Criando objeto ListaCont" << endl;
    max = tam;
    ultimo = -1;
    x = new float[max];
}

ListaCont::~ListaCont()
{
    cout << "Destruindo objeto ListaCont" << endl;
    delete [] x;
}

float ListaCont::consulta(int k)
{
    if(k >= 0 && k <= ultimo)
        return x[k];
    else
    {
        cout << "Indice invalido!" << endl;
        exit(1);
    }
}

void ListaCont::atribui(int k, float val)
{
    if(k >= 0 && k <= ultimo)
        x[k] = val;
    else
    {
        cout << "Indice invalido!" << endl;
        exit(2);
    }
}

void ListaCont::insereK(int k, float val)
{
    if(ultimo == max-1)
    {
        cout << "Vetor cheio!" << endl;
        exit(3);
    }

    if(k >= 0 && k <= ultimo)
    {
        for(int i = ultimo; i >= k; i--)
            x[i+1] = x[i];
        x[k] = val;
        ultimo = ultimo + 1;
    }
    else
    {
        cout << "Indice invalido!" << endl;
        exit(4);
    }
}

void ListaCont::insereUlt(float val)
{
    if(ultimo == max-1)
    {
        cout << "Vetor cheio!" << endl;
        exit(3);
    }
    ultimo = ultimo + 1;
    x[ultimo] = val;
}

void ListaCont::eliminaK(int k)
{
    if(k >= 0 && k <= ultimo)
    {
        for(int i = k; i <= ultimo-1; i++)
            x[i] = x[i+1];
        ultimo = ultimo - 1;
    }
    else
    {
        cout << "Indice invalido!" << endl;
        exit(5);
    }
}

void ListaCont::eliminaUlt()
{
    if(ultimo == -1)
    {
        cout << "Lista vazia!" << endl;
        exit(6);
    }
    ultimo = ultimo - 1;
}

void ListaCont::imprime()
{
    if(ultimo == -1)
        cout << "Lista vazia!" << endl;
    else
    {
        for(int i = 0; i <= ultimo; i++)
            cout << x[i] << "  ";
        cout << endl;
    }
}

int ListaCont::buscaMaior(float val)
{
    if(ultimo == -1)
    {
        cout << "Lista vazia!" << endl;
        exit(7);
    }

    for(int i = 0; i <= ultimo; i++)
    {
        if(x[i] > val)
            return i;
    }

    return -1;
}

int ListaCont::numNos()
{
    return ultimo + 1;
}

void ListaCont::limpar()
{
    if(ultimo == -1)
    {
        cout << "Lista vazia!" << endl;
        exit(8);
    }
    else
        ultimo = -1;
}

void ListaCont::insereValores(int tam, float vet[])
{
    if(numNos() + tam > max)
    {
        cout << "Tamanho do vetor superior ao espaco disponivel!" << endl;
        exit(9);
    }
    else
    {
        for(int i = 0; i < tam; i++)
            insereUlt(vet[i]);
    }
}
