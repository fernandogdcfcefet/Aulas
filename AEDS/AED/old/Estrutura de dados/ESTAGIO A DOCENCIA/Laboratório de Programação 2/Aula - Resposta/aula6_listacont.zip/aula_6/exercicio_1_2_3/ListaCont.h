#ifndef TLISTCONT_H_INCLUDED
#define TLISTCONT_H_INCLUDED

class ListaCont
{
    private:
        int max;
        int ultimo;
        float *x;

    public:
        ListaCont(int tam);
        ~ListaCont();

        float consulta(int k);
        void atribui(int k, float val);
        void insereK(int k, float val);
        void insereUlt(float val);
        void eliminaK(int k);
        void eliminaUlt();
        void imprime();
        int buscaMaior(float val);
        int numNos();
        void limpar();
        void insereValores(int tam, float vet[]);
};

#endif // TLISTCONT_H_INCLUDED
