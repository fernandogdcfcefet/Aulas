#include <iostream>
#include <stdlib.h> //rand()
#include <time.h>   //time()
#include "Ponto2D.h"
#include "ListaCont.h"

using namespace std;

int numAleatorio(int a, int b)
{
    // retorna um numero inteiro aleatório entre a e b
    return a + rand()%(b - a + 1) ;
}

int main()
{
    int tam = 5;
    srand(time(NULL));

    ListaCont l(tam);
    for(int i = 0; i < tam; i++)
    {
        float x = numAleatorio(0,50);
        float y = numAleatorio(0,50);
        Ponto2D* p = new Ponto2D(x,y);
        l.insereUlt(p);
    }
    l.calculaDistPontos();

    return 0;
}
