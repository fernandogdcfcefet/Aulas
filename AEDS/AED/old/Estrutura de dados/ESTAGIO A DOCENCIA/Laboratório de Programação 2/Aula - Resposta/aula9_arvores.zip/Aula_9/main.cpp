#include <iostream>
#include "ArvBin.h"
using namespace std;

int main()
{
    //constr�i 5 �rvores bin�rias vazias
    ArvBin *arv = new ArvBin();
    ArvBin *a1 = new ArvBin();
    ArvBin *a2 = new ArvBin();
    ArvBin *a3 = new ArvBin();
    ArvBin *vazia = new ArvBin();

    //as 2 arvores possuem ra�zes 6 e 9 e sae e sad vazias
    a1->cria(6, vazia, vazia);
    a2->cria(9 ,vazia, vazia);

    //raiz de Arv tem valor 8 e sae a1 e sad a2
    arv->cria(8, a1, a2);

    a1->cria(18, vazia, vazia);
    a2->cria(14, vazia, vazia);
    a3->cria(-5, a1, a2);

    //raiz de Arv tem valor 10 e sae Arv e sad a3
    arv->cria(10, arv, a3);

    a1->cria(25, vazia, vazia);
    a2->cria(33, vazia, vazia);
    a3->cria(30, a1, a2);

    //raiz de Arv tem valor 20 e sae Arv e sad a3
    arv->cria(20, arv, a3);

    //
    // TESTES: faca seus testes aqui
    //

    //imprime a �rvore constru�da nos comandos acima
    arv->emOrdem();

    cout << "\nNum nos da arvore: " << arv->contaNos();
    cout << "\nNum nos folhas da arvore: " << arv->contaNosFolhas();
    cout << "\nAltura da Arvore: " << arv->altura();
    cout << "\nNum nos impares da arvore: " << arv->contaImpar();
    cout << "\nNum nos folhas impares da arvore: " << arv->contaFolhaImpar();
    arv->imprimeNivel(2);
    cout << "\nMedia dos valores do Nivel K: " << arv->mediaNivel(2);
    cout << "\nO menor valor da arvore eh: " << arv->min();
    cout << "\nO maior valor da arvore eh: " << arv->max();
    cout << "\nO Valor no no mais a direita eh: " << arv->noMaisDireita();
    cout << "\nO Valor no no mais a esquerda eh: " << arv->noMaisEsquerda();

    cout << "\nMaior valor da sub-arvore a esquerda da raiz: " << arv->testaMaxSubArvore();
    cout << "\nMenor valor da sub-arvore a esquerda da raiz: " << arv->testaMinSubArvore() << endl;

    if(arv->ehABB())
        cout << "Eh arvore binaria de busca. " << endl;
    else
        cout << "Nao eh arvore binaria de busca. " << endl;

    arv->emOrdem();
    arv->inverte();
    arv->emOrdem();

    //
    // FIM DOS TESTES
    //

    delete arv;

    return 0;
}
