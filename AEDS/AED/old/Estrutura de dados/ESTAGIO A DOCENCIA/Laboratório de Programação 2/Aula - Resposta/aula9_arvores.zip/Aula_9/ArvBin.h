#ifndef ARVBIN_H_INCLUDED
#define ARVBIN_H_INCLUDED
#include "No.h"

class ArvBin
{
  public:
    ArvBin();
    ~ArvBin();
    int consultaRaiz();
    void cria(int x, ArvBin *sae, ArvBin *sad);
    bool vazia(); // verifica se a �rvore est� vazia
    bool busca(int x);
    void emOrdem();
    int altura();
    int contaNos();
    int contaNosFolhas();
    int contaImpar();
    int contaFolhaImpar();
    void imprimeNivel(int k);
    float mediaNivel(int k);
    int min();
    int max();
    void inverte();
    int noMaisEsquerda();
    int noMaisDireita();
    int minSubArvore(No * p);
    int testaMinSubArvore();
    int maxSubArvore(No * p);
    int testaMaxSubArvore();
    bool ehABB();

  private:
    No* raiz; // ponteiro para o No raiz da �rvore
    bool auxBusca(No *p, int C);
    No* libera(No *p);
    void auxEmOrdem(No *p);
    int auxaltura(No* p);
    int auxContaNos(No* p);
    int auxcontaNosFolhas(No* p);
    int auxcontaImpar(No* p);
    int auxcontaFolhaImpar(No* p);
    void auximprimeNivel(No* p, int k);
    void auxmediaNivel(No* p, int k, float* soma, int* cont);
    void auxmin(No *p, int* menor);
    void auxmax(No *p, int* maior);
    void auxInverte(No *p);
    int auxnoMaisEsquerda(No* p);
    int auxnoMaisDireita(No* p);
    bool auxEhABB(No * p);

};

#endif // ARVBIN_H_INCLUDED
