#include <iostream>
#include <cstdlib>
#include "ArvBin.h"

using namespace std;

ArvBin::ArvBin()
{
    raiz = NULL;
}

int ArvBin::consultaRaiz()
{
    if (raiz != NULL)
        return raiz->consultaInfo();
    else
    {
        cout << "�rvore vazia!" << endl;
        exit(1);
    }
}

void ArvBin::cria(int x, ArvBin *sae, ArvBin *sad)
{
    No *p = new No();
    p->atribInfo(x);
    p->atribEsq(sae->raiz);
    p->atribDir(sad->raiz);
    raiz = p;
}

bool ArvBin::vazia()
{
    if (raiz == NULL)
        return true;
    else
        return false;
}

bool ArvBin::busca(int x)
{
    return auxBusca(raiz, x);
}

bool ArvBin::auxBusca(No *p, int C)
{
    if (p == NULL)
        return false;
    else if (p->consultaInfo() == C)
        return true;
    else if (auxBusca(p->consultaEsq(), C))
        return true;
    else
        return auxBusca(p->consultaDir(), C);
}

ArvBin::~ArvBin()
{
    raiz = libera(raiz);
}

No* ArvBin::libera(No *p)
{
    if (p != NULL)
    {
        p->atribEsq(libera(p->consultaEsq()));
        p->atribDir(libera(p->consultaDir()));
        delete p;
        p = NULL;
    }
    return NULL;

}

void ArvBin::emOrdem()
{
    cout << "Arvore Binaria: ";
    auxEmOrdem(raiz);
}

void ArvBin::auxEmOrdem(No *p)
{
    if (p != NULL)
    {
        auxEmOrdem(p->consultaEsq());
        cout << p->consultaInfo() << " ";
        auxEmOrdem(p->consultaDir());
    }
}

/*------------------
    EXERCICIO 1
------------------*/

int ArvBin::contaNos()
{
    return auxContaNos(raiz);
}

int ArvBin::auxContaNos(No* p)
{
    if(p == NULL)
        return 0;
    else
        return 1 + auxContaNos(p->consultaDir()) + auxContaNos(p->consultaEsq());
}

/*------------------
    EXERCICIO 2
------------------*/

int ArvBin::contaNosFolhas()
{
    return auxcontaNosFolhas(raiz);
}

int ArvBin::auxcontaNosFolhas(No* p)
{
    if(p == NULL)
        return 0;
    else
    {
        if(p->consultaDir()==NULL && p->consultaEsq()==NULL)
            return 1;
        else
            return auxcontaNosFolhas(p->consultaDir()) + auxcontaNosFolhas(p->consultaEsq());
    }
}

/*------------------
    EXERCICIO 3
------------------*/

int ArvBin::altura()
{
    return auxaltura(raiz);
}

int ArvBin::auxaltura(No *p)
{
    if(p == NULL)
        return 0;
    else
    {
        int alturaesq = auxaltura(p->consultaEsq());
        int alturadir = auxaltura(p->consultaDir());

        if(alturadir > alturaesq)
            return alturadir + 1;
        else
            return alturaesq + 1;

    }
}

/*------------------
    EXERCICIO 4
------------------*/

int ArvBin::contaImpar()
{
    return auxcontaImpar(raiz);
}

int ArvBin::auxcontaImpar(No* p)
{

    if(p == NULL)
        return 0;
    else
    {
        if(p->consultaInfo()%2 != 0)
            return 1 + auxcontaImpar(p->consultaDir()) + auxcontaImpar(p->consultaEsq());
        else
            return auxcontaImpar(p->consultaDir()) + auxcontaImpar(p->consultaEsq());
    }
}


/*------------------
    EXERCICIO 5
------------------*/


int ArvBin::contaFolhaImpar()
{
    return auxcontaFolhaImpar(raiz);
}

int ArvBin::auxcontaFolhaImpar(No* p)
{


    if(p == NULL)
        return 0;
    else
    {
        if( (p->consultaInfo()%2 != 0) && (p->consultaDir()==NULL && p->consultaEsq()==NULL) )
            return 1;
        else
            return auxcontaFolhaImpar(p->consultaDir()) + auxcontaFolhaImpar(p->consultaEsq());
    }

}

/*------------------
    EXERCICIO 6
------------------*/

void ArvBin::imprimeNivel(int k)
{
    if(vazia())
    {
        cout << "\nArvore Vazia!" << endl;
        exit(2);
    }

    if(k > altura())
    {
        cout << "\nNivel K maior que a altura da arvore!" << endl;
        exit(3);
    }

    cout<< "\nImprimindo valores do nivel " << k << ": ";
    auximprimeNivel(raiz, k);
}

void ArvBin::auximprimeNivel(No *p, int k)
{
    if(k == 0)
        cout << p->consultaInfo() << " ";
    else
    {
        auximprimeNivel(p->consultaDir(), k-1);
        auximprimeNivel(p->consultaEsq(), k-1);
    }
}

/*------------------
    EXERCICIO 7
------------------*/

float ArvBin::mediaNivel(int k)
{
    if(vazia())
    {
        cout << "\nArvore Vazia!" << endl;
        exit(4);
    }

    if(k > altura())
    {
        cout << "\nNivel K maior que a altura da arvore!" << endl;
        exit(5);
    }

    int cont = 0;
    float soma = 0.0;

    auxmediaNivel(raiz, k, &soma, &cont);

    return soma/cont;
}

void ArvBin::auxmediaNivel(No* p, int k, float* soma, int* cont)
{
    if(k == 0)
    {
        *cont = *cont + 1;
        *soma = *soma + p->consultaInfo();
    }
    else
    {
        auxmediaNivel(p->consultaDir(), k-1, soma, cont);
        auxmediaNivel(p->consultaEsq(), k-1, soma, cont);
    }

}

/*------------------
    EXERCICIO 8
------------------*/

int ArvBin::min()
{
    if(vazia())
    {
        cout << "\nArvore Vazia!" << endl;
        exit(6);
    }

    int menor = raiz->consultaInfo();
    auxmin(raiz->consultaDir(), &menor);
    auxmin(raiz->consultaEsq(), &menor);

    return menor;
}

void ArvBin::auxmin(No* p, int* menor)
{
    if(p != NULL)
    {
        if(p->consultaInfo() < *menor)
            *menor = p->consultaInfo();

        auxmin(p->consultaDir(), menor);
        auxmin(p->consultaEsq(), menor);
    }
}

int ArvBin::max()
{
    if(vazia())
    {
        cout << "\nArvore Vazia!" << endl;
        exit(7);
    }

    int maior = raiz->consultaInfo();
    auxmax(raiz->consultaDir(), &maior);
    auxmax(raiz->consultaEsq(), &maior);

    return maior;
}

void ArvBin::auxmax(No* p, int* maior)
{
    if(p != NULL)
    {
        if(p->consultaInfo() > *maior)
            *maior = p->consultaInfo();

        auxmax(p->consultaDir(), maior);
        auxmax(p->consultaEsq(), maior);
    }
}

/*------------------
    EXERCICIO 9
------------------*/

void ArvBin::inverte()
{
    cout<<"\nInvertendo a arvore!"<<endl;
    auxInverte(raiz);
}

void ArvBin::auxInverte(No* p)
{
    if(p != NULL)
    {
        if(p->consultaEsq() != NULL && p->consultaDir() != NULL)
        {
            int aux = p->consultaEsq()->consultaInfo();
            p->consultaEsq()->atribInfo(p->consultaDir()->consultaInfo());
            p->consultaDir()->atribInfo(aux);
        }

        auxInverte(p->consultaDir());
        auxInverte(p->consultaEsq());
    }
}

/*------------------
    EXERCICIO 10
------------------*/

int ArvBin::noMaisDireita()
{
    return auxnoMaisDireita(raiz);
}

int ArvBin::auxnoMaisDireita(No* p)
{
    if(p != NULL)
    {
        if(p->consultaDir() == NULL)
            return p->consultaInfo();
        else
            auxnoMaisDireita(p->consultaDir());
    }
}

int ArvBin::noMaisEsquerda()
{
    return auxnoMaisEsquerda(raiz);
}

int ArvBin::auxnoMaisEsquerda(No* p)
{
    if(p != NULL)
    {
        if(p->consultaEsq() == NULL)
            return p->consultaInfo();
        else
            auxnoMaisEsquerda(p->consultaEsq());
    }
}

/*------------------
    EXERCICIO 11
------------------*/

int ArvBin::minSubArvore(No* p)
{
    if(p == NULL)
    {
        cout << "\nSub-arvore Vazia!" << endl;
        exit(8);
    }

    int menor = p->consultaInfo();
    auxmin(p->consultaDir(), &menor);
    auxmin(p->consultaEsq(), &menor);
    return menor;
}

int ArvBin::testaMinSubArvore()
{
    return minSubArvore(raiz->consultaEsq());
}

int ArvBin::maxSubArvore(No* p)
{
    if(p == NULL)
    {
        cout << "\nSub-arvore Vazia!" << endl;
        exit(8);
    }

    int maior = p->consultaInfo();
    auxmax(p->consultaDir(), &maior);
    auxmax(p->consultaEsq(), &maior);
    return maior;
}

int ArvBin::testaMaxSubArvore()
{
    return maxSubArvore(raiz->consultaEsq());
}

/*------------------
    EXERCICIO 12
------------------*/

bool ArvBin::ehABB()
{
    return auxEhABB(raiz);
}

bool ArvBin::auxEhABB(No *p)
{
    if(p == NULL)
    {
        return true;
    }

    //Na sub-arvore da esquerda so pode haver elementos menores que o no raiz
    //Caso contrario, nao eh ABB
    if(p->consultaEsq() != NULL)
    {
        int maiorSubArvEsq = maxSubArvore(p->consultaEsq());

        if(maiorSubArvEsq >= p->consultaInfo())
            return false;
    }

    //Na sub-arvore da direita so pode haver elementos maiores que o no raiz
    //Caso contrario, nao eh ABB
    if(p->consultaEsq() != NULL)
    {
        int menorSubArvDir = minSubArvore(p->consultaDir());

        if(menorSubArvDir < p->consultaInfo())
            return false;
    }

    //Uma arvore eh ABB se todas suas sub-arvores sao ABBs.
    if(auxEhABB(p->consultaEsq()) && auxEhABB(p->consultaDir()))
        return true;
    else
        return false;
}

