#include <iostream>
using namespace std;

/* Exericio 1 */

int fatorialIt(int n){

    int f = 1;
    for(int i=1; i <= n; i++)
        f = i * f;

    return f;
}

/*------------*/

/* Exericio 2 */

void imprimeIntervaloIt(int a, int b, int inc){

    for(int i=a; i<=b; i+=inc){
        cout << i << " ";
    }
}

/*------------*/

/* Exericio 3 */

void imprimeDecrescenteIt(int n){

    for(int i=n; i>=0; i--){
        cout << i << " ";
    }
}

/*------------*/

/* Exericio 4 */

float menorIt(int n, float vetor[]){

    float menor = vetor[0];

    for(int i=1; i<n; i++)
        if(vetor[i] < menor)
            menor = vetor[i];

    return menor;
}

/*------------*/

/* Exericio 5 */

float somaIt(int n, float vetor[]){

    float soma = 0.0;

    for(int i=0; i<n; i++)
        soma += vetor[i];

    return soma;
}

/*------------*/

/* Exericio 6 */

int contaParesIt(int n, int vetor[]){

    int pares = 0;

    for(int i=0; i<n; i++)
        if(vetor[i] % 2 == 0)
            pares++;

    return pares;
}

int main(){
	
	cout << "Exercicio 8 - Implementacoes iterativas:" << endl;
	
	cout << "Exercicio 1:" << endl;
    cout << "Fatorial de 5: " << fatorialIt(5) << endl << endl;

    cout << "Exercicio 2:" << endl;
    imprimeIntervaloIt(1, 8, 2);

    cout << endl << endl;
    cout << "Exercicio 3:" << endl;
    imprimeDecrescenteIt(8);
    cout << endl << endl;

    cout << "Exercicio 4:" << endl;
    float vetor[] = {1, 2, 3, 4, 5};
    cout << menorIt(5,vetor) << endl << endl;

    cout << "Exercicio 5:" << endl;
    cout << somaIt(5,vetor) << endl << endl;

    cout << "Exercicio 6:" << endl;
    int vetor2[] = {1, 2, 3, 4, 5};
    cout << contaParesIt(5, vetor2) << endl << endl;	

	return 0;
}
