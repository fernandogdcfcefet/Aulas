#include <iostream>
using namespace std;

float menor(int n, float vetor[]){

    //Base da recursao
	if(n == 1)
        return vetor[n-1];

    //Passo recursivo - obtem o menor elemento do vetor de tamanho n-1 
    float valor = menor(n-1, vetor);

    //Compara com o ultimo elemento e retorna o menor
    if(valor < vetor[n-1])
        return valor;
    else
        return vetor[n-1];
}

int main(){
	
	cout << "Exercicio 4:" << endl;
    float vetor[5] = {1, 2, 3, 4, 5};
    cout << menor(5, vetor) << endl;

	return 0;
}
