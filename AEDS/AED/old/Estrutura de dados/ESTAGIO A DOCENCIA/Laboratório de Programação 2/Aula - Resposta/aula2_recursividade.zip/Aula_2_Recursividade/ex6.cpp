#include <iostream>
using namespace std;

int contaPares(int n, int vetor[]){

    //Base da recursao
    if(n == 1){
        if(vetor[n-1] % 2 == 0)
            return 1;
        else
            return 0;
    }

    //Passo recursivo - conta a qtd de numeros pares do vetor de tamanho n-1
    int pares = contaPares(n-1, vetor);

    if(vetor[n-1] % 2 == 0)
        return pares+1;
    else
        return pares;
}

int main(){
	
	cout << "Exercicio 6:" << endl;
    int vetor[] = {1, 2, 3, 4, 5};
    cout << contaPares(5,vetor) << endl;

	return 0;
}
