#include <iostream>
using namespace std;

void imprimeIntervalo(int a, int b, int inc){

    if(a<=b){
        cout << a << " ";
        imprimeIntervalo(a+inc, b, inc);
    }
}

int main(){
	
	cout << "Exercicio 2:" << endl;
    imprimeIntervalo(1, 8, 2);
    cout << endl;

	return 0;
}
