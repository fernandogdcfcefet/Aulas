#include <iostream>
using namespace std;

float soma(int n, float vetor[]){

    //Base da recursao
    if(n == 1)
        return vetor[n-1];
	
	//Passo recursivo
    return soma(n-1,vetor) + vetor[n-1];
}

int main(){
	
	cout << "Exercicio 5:" << endl;
    float vetor[] = {1, 2, 3, 4, 5};
    cout << soma(5, vetor) << endl << endl;

	return 0;
}
