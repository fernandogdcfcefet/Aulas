#include <iostream>
using namespace std;

void imprimeDecrescente(int n){	
	
    if(n >= 0){
        cout << n << " ";
        imprimeDecrescente(n-1);
    }
}

int main(){
	
	cout << "Exercicio 3:" << endl;
    imprimeDecrescente(8);
    cout << endl;

	return 0;
}
