#include <iostream>
using namespace std;

int fatorial(int n){

	//Base da recursao
    if(n==1 || n == 0)
        return 1;
	
	//Passo recursivo
    return n*fatorial(n-1);
}

int main(){
	
	cout << "Exercicio 1:" << endl;
    cout << "Fatorial de 5: " << fatorial(5) << endl << endl;

	return 0;
}
