#include "Prova.h"

// exercicio 7

Prova::Prova(int nq)
{
    cout << "Criando uma prova" << endl;
    N = nq;

    notasQuestoes = new double[N];
}

Prova::~Prova(){
    cout << "Destruindo objeto prova" << endl;
    delete [] notasQuestoes;
}

void Prova::leNotas(){

    cout << "Informe as notas das questoes :" << endl;

    for(int i=0; i < N; i++){
        cin >> notasQuestoes[i];
    }
}

void Prova::calculaNotaFinal(){

    //Inicializa a menor nota com a nota da primeira questao
    double menorNota = notasQuestoes[0];
    notaFinal = 0.0;

    for(int i=0; i < N; i++){
        notaFinal += notasQuestoes[i];

        if(notasQuestoes[i] < menorNota)
            menorNota = notasQuestoes[i];
    }

    //Desconsidera a menor nota obtida
    notaFinal -= menorNota;
}

double Prova::obtemNotaFinal(){
    return notaFinal;
}
