#include "Aluno.h"

Aluno::Aluno(string n, string m)
{
    cout << "Criando aluno" << endl;
    nome = n;
    matricula = m;
}

Aluno::~Aluno()
{
    cout << "Destruindo objeto aluno" << endl;

}

// ----------------------------------------------------------------------------
// Exercicio 1
// ----------------------------------------------------------------------------

void Aluno::leNotas()
{
    cout << "Informe as notas do aluno " << getNome() << ":" << endl;

    for(int i=0; i < 7; i++){
        cin >> notas[i];
    }
}

double Aluno::calculaMedia()
{
    double media = 0;

    for(int i=0; i < 7; i++)
        media += notas[i];

    media = media/7;

    return media;
}

// ----------------------------------------------------------------------------

void Aluno::setNome(string novo)
{
    nome = novo;
}

string Aluno::getNome()
{
    return nome;
}

// ----------------------------------------------------------------------------
// Exercicio 2
// ----------------------------------------------------------------------------

void Aluno::setIdade(int id)
{
    idade = id;
}

int Aluno::getIdade()
{
    return idade;
}

void Aluno::setMatricula(string mat)
{
    matricula = mat;
}

string Aluno::getMatricula()
{
    return matricula;
}
// ----------------------------------------------------------------------------


// ----------------------------------------------------------------------------
// Exercicio 5
// ----------------------------------------------------------------------------

void Aluno::leFrequencia(){

    cout << "Informe a frequencia do aluno " << getNome() << " (1 para true e 0 para false):" << endl;

    for(int i=0; i < 7; i++){
        cin >> frequencia[i];
    }
}

// ----------------------------------------------------------------------------


// ----------------------------------------------------------------------------
// Exercicio 6
// ----------------------------------------------------------------------------

void Aluno::imprimeRelatorio(){

    cout << endl << "Dados do aluno:" << endl;
    cout << "Nome: " << getNome() << endl;
    cout << "Idade: " << getIdade() << endl;
    cout << "Matricula: " << getMatricula() << endl;
    cout << "Media: " << calculaMedia() << endl << endl;

    cout << "Disciplina\t" << "Frequencia\t" << "Situacao" << endl;

    for(int i=0; i < 7; i++){
        cout << i << " \t\t";

        if(frequencia[i])
            cout << "Frequente\t";
        else
            cout << "Infrequente\t";

        if(notas[i] >= 60)
            cout << "Aprovado" << endl;
        else
            cout << "Reprovado" << endl;
    }
}

// ----------------------------------------------------------------------------
