#include <iostream>
#include "Aluno.h"
#include "Prova.h"

using namespace std;

int main()
{
    cout << "LABORATORIO DE PROGRAMACAO II - AULA 4\n" << endl;

    // ------------------------------------------------------------------------
    // EXERCICIO 1
    // ------------------------------------------------------------------------
    Aluno a("Carlos","201566123AB");
    a.setIdade(20);

    // leitura das notas do aluno
    a.leNotas();
    double m = a.calculaMedia();

    cout << "Media do aluno: " << m << endl;

    // ------------------------------------------------------------------------
    // EXERCICIO 3
    // ------------------------------------------------------------------------

    cout << endl << "Dados do aluno:" << endl;
    cout << "Nome: " << a.getNome() << endl;
    cout << "Matricula: " << a.getMatricula() << endl;
    cout << "Idade: " << a.getIdade() << endl;
    cout << "Media do aluno: " << a.calculaMedia() << endl;

    // ------------------------------------------------------------------------
    // EXERCICIO 5
    // ------------------------------------------------------------------------

    a.leFrequencia();

    // ------------------------------------------------------------------------
    // EXERCICIO 6
    // ------------------------------------------------------------------------

    a.imprimeRelatorio();

    // ------------------------------------------------------------------------
    // EXERCICIO 7
    // ------------------------------------------------------------------------

    Prova p(3);
    p.leNotas();
    p.calculaNotaFinal();
    cout << "Nota final: " << p.obtemNotaFinal() << endl;

    return 0;
}
