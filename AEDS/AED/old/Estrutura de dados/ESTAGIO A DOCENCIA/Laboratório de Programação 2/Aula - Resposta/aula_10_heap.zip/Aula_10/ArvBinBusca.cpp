#include <iostream>
#include "ArvBinBusca.h"

using namespace std;

ArvBinBusca::ArvBinBusca()
{
    raiz = NULL;
}

bool ArvBinBusca::vazia()
{
    return raiz == NULL;
}

void ArvBinBusca::insere(int C)
{
    raiz = auxInsere(raiz, C);
}

No* ArvBinBusca::auxInsere(No *p, int C)
{
    if(p == NULL)
    {
        p = new No;
        p->setInfo(C);
        p->setEsq(NULL);
        p->setDir(NULL);
    }
    else if(C < p->getInfo())
        p->setEsq(auxInsere(p->getEsq(), C));
    else
        p->setDir(auxInsere(p->getDir(), C));
    return p;
}

bool ArvBinBusca::busca(int C)
{
    return auxBusca(raiz, C);
}

bool ArvBinBusca::auxBusca(No* p, int C)
{
    if(p == NULL)
        return false;
    else if(p->getInfo() == C)
        return true;
    else if(C < p->getInfo())
        return auxBusca(p->getEsq(), C);
    else
        return auxBusca(p->getDir(), C);
}

void ArvBinBusca::remove(int C)
{
    raiz = auxRemove(raiz, C);
}

No* ArvBinBusca::auxRemove(No* p, int C)
{
    if(p == NULL)
        return NULL;
    else if(C < p->getInfo())
        p->setEsq(auxRemove(p->getEsq(), C));
    else if(C > p->getInfo())
        p->setDir(auxRemove(p->getDir(), C));
    else
    {
        if(p->getEsq() == NULL && p->getDir() == NULL)
            p = removeFolha(p);
        else if((p->getEsq() == NULL) || (p->getDir() == NULL))
            p = remove1Filho(p);
        else
        {
            //No *aux = menorSubArvDireita(p);
            No *aux = maiorSubArvEsquerda(p);
            int auxC = aux->getInfo();
            p->setInfo(auxC);
            aux->setInfo(C);
            p->setDir(auxRemove(p->getDir(), C));
        }
    }
    return p;
}

No* ArvBinBusca::removeFolha(No *p)
{
    delete p;
    return NULL;
}

No* ArvBinBusca::remove1Filho(No *p)
{
    No *aux;
    if(p->getEsq() == NULL)
        aux = p->getDir();
    else
        aux = p->getEsq();
    delete p;
    return aux;
}

No* ArvBinBusca::menorSubArvDireita(No *p)
{
    No *aux = p->getDir();
    while(aux->getEsq() != NULL)
        aux = aux->getEsq();
    return aux;
}

void ArvBinBusca::imprime()
{
    imprimePorNivel(raiz, 0);
}

void ArvBinBusca::imprimePorNivel(No* p, int nivel)
{
    if (p != NULL)
    {
        cout << "(" << nivel << ")";
        for(int i = 1; i <= nivel; i++)
            cout << "--";
        cout << p->getInfo() << endl;
        imprimePorNivel(p->getEsq(), nivel+1);
        imprimePorNivel(p->getDir(), nivel+1);
    }
}

ArvBinBusca::~ArvBinBusca()
{
    raiz = libera(raiz);
}

No* ArvBinBusca::libera(No *p)
{
    if(p != NULL)
    {
        p->setEsq(libera(p->getEsq()));
        p->setDir(libera(p->getDir()));
        delete p;
        p = NULL;
    }
    return p;
}

float ArvBinBusca::mediaCaminho(int ch)
{
    int soma = 0, cont = 0;
    if(raiz != NULL)
    {
        No *p = raiz;
        while(p->getInfo() != ch && p != NULL)
        {
            cont = cont + 1;
            soma = soma + p->getInfo();
            if(ch > p->getInfo())
                p = p->getDir();
            else
                p = p->getEsq();
        }
        if(p != NULL) // soma contribuicao do no com valor ch
        {
            cont = cont + 1;
            soma = soma + p->getInfo();
        }
    }
    return (float)soma/cont;
}

/*------------------
    EXERCICIO 1
------------------*/

int ArvBinBusca::maior()
{
    if(vazia())
    {
        cout << "Árvore vazia!" << endl;
        exit(1);
    }

    return auxMaior(raiz);
}

int ArvBinBusca::auxMaior(No *p)
{
    if(p->getDir() != NULL)
        return auxMaior(p->getDir());
    else
        return p->getInfo();
}

/*------------------
    EXERCICIO 2
------------------*/

int ArvBinBusca::menor()
{
    if(vazia())
    {
        cout << "Árvore vazia!" << endl;
        exit(1);
    }

    return auxMenor(raiz);
}

int ArvBinBusca::auxMenor(No *p)
{
    if(p->getDir() != NULL)
        return auxMenor(p->getEsq());
    else
        return p->getInfo();
}


/*------------------
    EXERCICIO 3
------------------*/

void ArvBinBusca::removeMaior()
{
    if(vazia())
    {
        cout << "Árvore vazia!" << endl;
        exit(1);
    }

    cout << "Removendo maior elemento" << endl;

    raiz = auxRemoveMaior(raiz);
}

No* ArvBinBusca::auxRemoveMaior(No *p)
{
    if(p->getDir() != NULL)
    {
        p->setDir(auxRemoveMaior(p->getDir()));
    }
    else
    {
        //p aponta para o maior elemento
        if(p->getEsq() == NULL)
            p = removeFolha(p);
        else
            p = remove1Filho(p);
    }

    return p;
}


/*------------------
    EXERCICIO 4
------------------*/

void ArvBinBusca::removeMenor()
{
    if(vazia())
    {
        cout << "Árvore vazia!" << endl;
        exit(1);
    }

    cout << "Removendo menor elemento" << endl;

    raiz = auxRemoveMenor(raiz);
}

No* ArvBinBusca::auxRemoveMenor(No *p)
{
    if(p->getDir() != NULL)
    {
        p->setEsq(auxRemoveMenor(p->getEsq()));
    }
    else
    {
        //p aponta para o menor elemento
        if(p->getDir() == NULL)
            p = removeFolha(p);
        else
            p = remove1Filho(p);
    }

    return p;
}

/*------------------
    EXERCICIO 5
------------------*/

int ArvBinBusca::contaParesCaminho(int ch)
{
    int cont = 0;
    if(raiz != NULL)
    {
        No *p = raiz;
        while(p->getInfo() != ch && p != NULL)
        {
            if(p->getInfo() % 2 == 0)
                cont = cont + 1;

            if(ch > p->getInfo())
                p = p->getDir();
            else
                p = p->getEsq();
        }
        if(p != NULL)
        {
            if(p->getInfo() % 2 == 0)
                cont = cont + 1;
        }
    }

    return cont;
}


/*------------------
    EXERCICIO 6
------------------*/

No* ArvBinBusca::maiorSubArvEsquerda(No *p)
{
    No *aux = p->getEsq();
    while(aux->getDir() != NULL)
        aux = aux->getDir();
    return aux;
}

/*------------------
    EXERCICIO 7
------------------*/

void ArvBinBusca::preencheABB(ArvBinBusca* a, int p, int q)
{
    int meio;
    int tamanho_intervalo = q - p + 1;

    //base da recursao
    if(tamanho_intervalo < 1)
        return;

    meio =  p + tamanho_intervalo/2;

    a->insere(meio);
    preencheABB(a,p,meio-1);
    preencheABB(a,meio+1,q);
}
