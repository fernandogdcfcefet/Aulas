package ods;

/**
 * This class implements the Patricia Trie data structure.  This is a tree 
 * whose internal nodes all have 2 or more children and whose edges are 
 * labelled with strings.  Each leaf, v, corresponds to a string stored in the
 * trie that can be obtained by concatenating the labels of all edges on
 * the path from the root to v.
 * @author morin
 *
 */
public class PatriciaTrie {
	
	protected static class Edge {
		Node target;
		PString label;
		public Edge(Node target, PString label) {
			this.target = target;
			this.label = label;
		}
	}
	
	protected static class Node {
		Edge[] edges;     // the children of this node
		int nc;           // the number of children
		public Node() {
			edges = new Edge[128];
			nc = 0;
		}
	}
	
	/**
	 * The number of strings stored in the trie
	 */
	protected int n;
	
	/**
	 * The root
	 */
	protected Node r;
	
	public PatriciaTrie() {
		r = new Node();
		n = 0;
	}

	/** 
	 * Add the x to this trie
	 * @param x the string to add
	 * @return true if x was successfully added or false if x is already in the trie
	 */
	public boolean add(PString x) {
		// TODO: complete this method
		return false;
	}

	/** 
	 * Remove x from this trie
	 * @param x the string to remove
	 * @return true if x was successfully removed or false if x is not stored in the trie
	 */
	public boolean remove(PString x) {
		// TODO: complete this method
		return false;
	}

	/**
	 * Return the PString stored in this trie that is equal to x
	 * @param x
	 * @return a PString equal x if x was found and null otherwise
	 */
	public PString search(PString x) {
		// TODO: complete this method
		return null;
	}
	
	/**
	 * Find a string whose prefix matches x
	 * @return a PString y such that the prefix of y is equal to x
	 * or null if no such string exists
	 */
	public PString prefixSearch1(PString x) {
		return null;
	}
	
	/**
	 * Find all strings whose prefix matches x
	 * @param x
	 * @return an array containing every string whose prefix matches x
	 */
	public PString[] prefixSearchMany(PString x) {
		return null;
	}
}
