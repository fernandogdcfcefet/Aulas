package comp5408;


import java.util.Comparator;
import java.util.Random;


public class Treap<T> extends
		BinarySearchTree<Treap.Node<T>, T> implements SSet<T> {
	/**
	 * A random number source
	 */
	Random rand;

	protected static class Node<T> extends BinarySearchTree.BSTNode<Node<T>,T> {
		int p;
	}
	
	public Treap(Comparator<T> c) {
		super(new Node<T>(), c);
		rand = new Random();
	}

	public Treap() {
		this(new DefaultComparator<T>());	
	}

	public Treap(T[] a) {
		this(a, new DefaultComparator<T>());	
	}

	public boolean add(T x) {
		Node<T> u = newNode();
		u.x = x;
		u.p = rand.nextInt();
		if (super.add(u)) {
			bubbleUp(u);
			return true;
		}
		return false;
	}

	protected void bubbleUp(Node<T> u) {
		while (u.parent != nil && u.parent.p > u.p) {
			if (u.parent.right == u) {
				rotateLeft(u.parent);
			} else {
				rotateRight(u.parent);
			}
		}
		if (u.parent == nil) {
			r = u;
		}
	}

	public boolean remove(T x) {
		Node<T> u = findLast(x);
		if (u != nil && c.compare(u.x, x) == 0) {
			trickleDown(u);
			splice(u);
			return true;
		}
		return false;
	}

	/**
	 * Do rotations to make u a leaf
	 */
	protected void trickleDown(Node<T> u) {
		while (u.left != nil || u.right != nil) {
			if (u.left == nil) {
				rotateLeft(u);
			} else if (u.right == nil) {
				rotateRight(u);
			} else if (u.left.p < u.right.p) {
				rotateRight(u);
			} else {
				rotateLeft(u);
			}
			if (r == u) {
				r = u.parent;
			}
		}
	}
	
	/**
	 * Remove all elements greater than or equal to x from this treap. Return a new treap
	 * that contains all the elements greater or equal to x
	 * @param x
	 * @return a Treap containing all elements greater than x
	 */
	public Treap<T> split(T x) {
		Treap<T> t = new Treap<T>(c);
		// TODO: implement this
		return t;
	}

	/**
	 * Merge this treap and t into a single treap, emptying t in the process
	 * Precondition: Every element in t is greater than every element in this
	 * treap
	 * 
	 * @param t
	 * @return true if successful and false if the precondition is not satisfied
	 */
	public boolean merge(Treap<T> t) {
		// TODO: implement this
		return false;
	}
	
	/**
	 * Return the item in the treap whose rank is i - This is the item x such
	 * that the treap contains exactly i element less than x.
	 * 
	 * @param i
	 * @return
	 */
	public T get(int i) {
		// TODO: implement this
		return null;
	}

	/**
	 * Build a treap that contains the elements of the (already sorted) array a
	 * This code must run in O(n) time - don't just call add(x) a.length times.
	 * 
	 * @param a
	 * @param c
	 */
	public Treap(T[] a, Comparator<T> c) {
		super(new Node<T>(), c);
		rand = new Random();
		// TODO: Your code to add the elements of a goes here
	}

}
