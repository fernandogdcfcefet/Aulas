package comp5408;

import java.util.List;
import java.util.ArrayList;
import java.util.Random;

public class FractionalIteratedSearcher<T extends Comparable<T>> 
		implements IteratedSearcher<T> {

	/**
	 * Constructor made from a list of sorted lists
	 * 
	 * @param lists - a list of sorted lists
	 */
	public FractionalIteratedSearcher(List<List<T>> lists) {
		// TODO: Write this code
	}
	
	@Override
	public List<T> find(T x) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static void main(String[] args) {
		// Some dumb test code
		System.out.print("Generating data ...");
		System.out.flush();
		long start = System.nanoTime();
		Random rand = new Random();
		int h = 20, n = 1000000;
		List<List<Integer>> lists = new ArrayList<List<Integer>>();
		int max = 0;
		for (int i = 0; i < h; i++) {
			List<Integer> ell = new ArrayList<Integer>();
			int x = 0;
			for (int j = 0; j < n; j++) {
				x += Integer.numberOfTrailingZeros(rand.nextInt())+1;
				ell.add(x);
			}
			if (x > max) max = x;
			lists.add(ell);
		}
		long stop = System.nanoTime();
		System.out.println("done (" + (stop-start)*1e-9 + "s)");

		System.out.print("Building iterated searcher...");
		System.out.flush();
		start = System.nanoTime();
		IteratedSearcher<Integer> is 
			= new FractionalIteratedSearcher<Integer>(lists);
		stop = System.nanoTime();
		System.out.println("done (" + (stop-start)*1e-9 + "s)");

		System.out.print("Doing "+ n + " searches...");
		System.out.flush();
		start = System.nanoTime();
		for (int i = 0; i < n; i++) {
			int x = rand.nextInt(max+10);
			@SuppressWarnings("unused")
			List<Integer> result = is.find(x);
			/* if (i < 5) {
				System.out.print("" + x + " =>");
				for (Integer y : result) {
					System.out.print(" " + y);
				}
				System.out.println();
			} */
		}
		stop = System.nanoTime();
		System.out.println("done (" + (stop-start)*1e-9 + "s)");
		
	}

}
