package comp5408;

import java.util.List;

public interface IteratedSearcher<T extends Comparable<T>> {
	List<T> find(T x);

}
