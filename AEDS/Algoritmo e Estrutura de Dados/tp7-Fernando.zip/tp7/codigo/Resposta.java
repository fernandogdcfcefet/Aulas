public class Resposta{

	int custo;
	Lista caminho;

	public Resposta(int custo, Lista caminho){
		this.custo = custo;
		this.caminho = caminho;	
	}

	public void setCusto(int custo){
		this.custo = custo;	
	}

	public int getCusto(){
		return custo;	
	}

	public Lista getCaminho(){
		return caminho;	
	}

}
