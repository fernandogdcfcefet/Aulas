public class Lista{

	public static class No{
		int val;
		No prox;	
	}

	No no;
	No retorna;
	
	public Lista(){
		no = new No();
		no.val = 0;
		no.prox = null;	
	}	

	public int getPrimeiro(){
		retorna = no;
		if(retorna.prox != null){
			retorna = retorna.prox;
			return retorna.val;		
		}
		return -1;
	}

	public int getProx(){
		if(retorna.prox != null){
			retorna = retorna.prox;
			return retorna.val;		
		}	
		return -1;
	}

	public void setNo(No no){
		this.no = no;	
	}
		
	public No getNo(){
		return no;	
	}

	public void insere(int valor){
		No aux = no;
		No ins = new No();
		ins.val = valor;
		ins.prox = null;		
		while(aux.prox != null){
			aux = aux.prox;		
		}
		aux.prox = ins;	
	}

	public int size(){
		int cont = 0;		
		No aux = no;
		while(aux.prox != null){
			aux = aux.prox;
			cont ++;		
		}
		return cont;
	}

	public boolean procura(int valor){
		No aux = no;
		while(aux.prox != null){
			aux = aux.prox;
			if(aux.val == valor)
				return true;		
		}
		return false;	
	}

	public void imprime(){
		System.out.print("Caminho: ");
		No aux = no;
		while(aux.prox != null){
			aux = aux.prox;
			System.out.print(aux.val + "    ");		
		}	
	}

}
