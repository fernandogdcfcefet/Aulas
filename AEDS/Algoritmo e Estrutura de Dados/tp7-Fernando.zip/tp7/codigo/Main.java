public class Main{

	static int contador = 0;

	public static Resposta PCV(JGrafo grafo, Lista visitados, int u){
		int tam = grafo.getTamanho();		
		visitados.insere(u);
		int min = -1;
		boolean visitou = false;
		if (visitados.size() == tam){
			contador ++;
			Resposta resposta = new Resposta(grafo.getPeso(u,0), visitados);
			return resposta;
		}
		Resposta resposta = new Resposta(0, new Lista());
		int v = grafo.primeiroListaAdj(u);
		if(v != -1){
			visitou = visitados.procura(v);		
			if(!visitou){
				Lista visitados2 = new Lista();
				int inserir = visitados.getPrimeiro();
				while(inserir != -1){
					visitados2.insere(inserir);
					inserir = visitados.getProx();									
				}
				resposta = PCV(grafo, visitados2, v);
				min = grafo.getPeso(u,v) + resposta.getCusto();		
			}
		}			
		v = grafo.proxAdj(u);			
		while(v != -1){
			visitou = false;
			visitou = visitados.procura(v);		
			if(!visitou){
				Lista visitados2 = new Lista();
				int inserir = visitados.getPrimeiro();
				while(inserir != -1){
					visitados2.insere(inserir);
					inserir = visitados.getProx();									
				}
				Resposta r2 = PCV(grafo, visitados2, v);
				int aux = grafo.getPeso(u,v) + r2.getCusto(); 
				if(min > aux || min < 0){
					resposta = r2;
					min = aux;
				}		
			}
			
			v = grafo.proxAdj(u);
		}			
		resposta.setCusto(min);
		return resposta;
		
	} 

	public static void main(String args[]){

		int max = 14;

		for(int i=2; i<=max; i++){
			JGrafo grafo = new JGrafo(i);
			for (int j=0; j<i; j++){
				for(int k=0; k<i; k++){
					if(j==k){
						grafo.insereAresta(j,j,0);
						//System.out.print("     0     ");
					}
					else{
						int r = Integer.parseInt(Math.round((Math.random()*99+1))+"");
						grafo.insereAresta(j,k,r);
						//System.out.print("     " + r + "     ");
					}
				}
				System.out.println();							
			}
			contador = 0;
			long tempoInicial = System.currentTimeMillis();
			Resposta resposta = PCV(grafo, new Lista(), 0);
			long tempoFinal = System.currentTimeMillis();
			System.out.println("Tamanho: " + i + "\n"); 
			System.out.println("Custo: " + resposta.getCusto());
			resposta.getCaminho().imprime();
			System.out.print("0\n");
			System.out.println("Número de rotas avaliadas: " + contador);
			System.out.println("Tempo: " + (tempoFinal - tempoInicial) +" ms");
		}

		
	}

}
